<?php
define('EMAIL','swarnakarr34@gmail.com');
define('PASS', 'Codewithbapi');

?>