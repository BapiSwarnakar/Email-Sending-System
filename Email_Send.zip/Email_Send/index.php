<!DOCTYPE html>
<html>
<head>
	<title>Email Send</title>
</head>
<body>
	<form method="post" action="action.php">
		<input type="email" name="email">
		<input type="submit" name="submit" value="Send Email">
	</form>
</body>
</html>